#!/bin/bash

/etc/init.d/ssh start
ssh -t root@localhost "cd /opt/pwnpad/scripts/ ; ./findmyhash1.sh ; bash"
