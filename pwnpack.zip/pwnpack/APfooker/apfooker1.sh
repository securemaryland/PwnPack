#!/bin/bash
#####################
# Pwnpad port of the AP_Fuck** script found on top-hat forums
#Original Author MatTouFoutu
# pwnpad conversion by: SecureMaryland
# Script for various means to deauth users on wireless APs
#####################
#####################
VERSION="1.0"
###################################################################################################################
# Intro
#
f_intro(){
clear
echo ""
echo "Checking to see if APFooker is installed. This may take a second or two please be patient."
configdir=/opt/pwnpad/pwnpack
configfile=/opt/pwnpad/pwnpack/pwnpack.cfg
appname=AP_fucker.py
if [ -f "$configfile" ] 
then
cat $configfile | grep "$appname" >/dev/null 2>1
   if [ $? = 0 ]
   then
		installdir=`cat $configfile |grep $appname |cut -d ":" -f2`
		echo "Found the install directory: $installdir in the config file moving on."
   else 
		echo "Didn't see it in the config file. Searching for it now."
		installdir=`find / -name $appname -print |awk -F'/[^/]*$' '{print $1}'`
		if [ -n "$installdir" ]
		then
			echo "$installdir"
			echo "Found it moving on..."
			echo "Adding it to the config file to speed up next run."
			echo "$appname:$installdir">>$configfile
		else
			echo "Sorry I couldn't find: APfooker. Please make sure it is installed. Exiting now.."
			exit
		fi
	fi
else 
	echo "Didn't see it in the config file. Searching for it now."
	installdir=`find / -name $appname -print |awk -F'/[^/]*$' '{print $1}'`
		if [ -n "$installdir" ]
		then
			echo "$installdir"
			echo "Found it moving on..."
			echo "Adding it to the config file to speed up next run."
			mkdir -p $configdir
			echo "appname:/path/to/app" >>$configfile
			echo "$appname:$installdir">>$configfile
		else
			echo "Sorry I couldn't find: APFooker. Please make sure it is installed. Exiting now.."
			exit
fi
fi
echo ""
echo -e "\e[00;32m#############################################################\e[00m"
echo ""
echo "*** AP_fuck**.py Scanner script for the Pwnpad Version $VERSION  ***"
echo "*** Author: @securemaryland ***"
echo "*** Launches AP_fuck**.py tool from Top-Hat-Security Forums  ***"
echo "*** Python portion written by matToufoutu ***"
echo ""
echo -e "\e[00;32m#############################################################\e[00m"
echo ""
echo ""
echo -e "\e[1;33mPress Enter to continue\e[00m"
echo ""
read ENTERKEY
clear
}
##########################################################################################################################
##########################################################################################################################
# Function to check for wlan1 and set up monitoring
f_wireless(){
adaptor=`ip addr |grep wlan1`
if [ -z "$adaptor" ]; then
echo "This script requires wlan1 to be plugged in."
echo "I cant see it so exiting now. Try again when wlan1 is plugged in."
exit 1
fi
echo " Found wlan1 now checking if monitor mode is on - don't worry I will turn it on if it isn't running"
iwconfig |grep Monitor>/dev/null
if [ $? = 1 ]
then
	echo
	echo "Monitor mode doesn't seem to be running. I will issue an airmon-ng start wlan1 to start it"
	echo ""
	airmon-ng start wlan1
else
	echo "Monitor mode appears to be running. Moving on."
fi
echo ""
echo -e "\e[1;33m-----------------------------------------------------------------\e[00m"
echo "AP_fuck**.py expects you to know the ESSID and BSSID for the APs you want to F with. If you don't know those may I suggest running airodump-ng in another window"
echo ""
echo "Press enter to launch AP_fuc**.py"
echo -e "\e[1;33m-----------------------------------------------------------------\e[00m"
read ENTERKEY
}
##########################################################################################################################
f_intro
f_wireless
python $installdir/AP_fucker.py

