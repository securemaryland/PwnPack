#!/bin/bash
# Configuration setup for the pwnpack tools - may not be the best way of doing things but better than what it was.
# www.securemaryland.org
# @securemaryland
#Tested on Pwnpad Community Edition
# 
VERSION="1.0"
###################################################################################################################
# Intro
#
f_intro(){
clear
echo ""
echo "Checking if the tools used by pwnpack are installed. Will automate the installation process where/when it can."
configdir=/opt/pwnpad/pwnpack
configfile=/opt/pwnpad/pwnpack/pwnpack.cfg
if [ ! -f "$configfile" ]; then
  # Control will enter here and create $configdir if it doesn't exist.
  echo "Didin't see the configuration file $configfile so I created it"
  mkdir -p "$configdir"
  echo "appname:/path/to/app">> $configfile
fi
cd $configdir
echo -e "\e[1;31m-------------------------------------------------------------------\e[00m"
echo "Looking for the files and installing them if not found. This will take sometime as I have to search for them and get them if not here."
echo ""
echo "Please be patient..."
echo -e "\e[1;31m-------------------------------------------------------------------\e[00m"
#There has to be a better way to do this but this was easy for me so it will do for now.
pwnpackscripts=("findmyhash.py" "cewl.rb" "Wsorrow.pl" "AP_fucker.py" "wpscan.rb" "theHarvester.py" "recon-ng.py")
for i in "${pwnpackscripts[@]}"
do
  cat $configfile | grep "$i" >/dev/null 2>&1
  if [ $? = 0 ]
	then
	echo "I see $i is already in the config file nothing more to do here"
else
echo "Can't find $i in the config file need ti search for it."
installdir=`find / -name $i -print |awk -F'/[^/]*$' '{print $1}'`
if [ -n "$installdir" ]
	then
		echo "Had to search but found it here: $installdir"
		echo "Adding it to the configuration file to speed up next run."
		echo "$i:$installdir">>$configfile
	else
	echo "Please be sure to install $i"
fi
fi
done
}
############
f_intro