****Pwnpad Goodness brought to you by @securemaryland****

Copy both the nmapscan.sh and the nmapscan1.sh to the /opt/pwnpad/scripts folder install the NMAP.apk and enjoy.

I cleaned up the code from lazymap and refined a lot of the processes but couldn't have done this without Lazymap
Original LazyMap Author: Daniel Compton

# www.commonexploits.com
 # contact@commexploits.com