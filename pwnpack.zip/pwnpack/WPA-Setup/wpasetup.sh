#!/bin/bash

/etc/init.d/ssh start
ssh -t root@localhost "cd /opt/pwnpad/wireless/ ; ./wpasetup1.sh ; bash"
