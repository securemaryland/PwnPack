****Pwnpad Goodness brought to you by @securemaryland****


Copy both the wpasetup.sh to the /opt/pwnpad/scripts folder and the wpasetup1.sh to the /opt/pwnpad/wireless folder (thought it mad more sense to be put there) install the WLAN1WPA-Setup.apk and enjoy.

Note this only works for setting up the wlan1 card (tp-link) to a wpa protected wireless connection.