#!/bin/bash
#####################
#Quick script to start monitoring
#####################
#####################

VERSION="1.0"
###################################################################################################################
# Intro
#
f_intro(){
clear
echo ""
echo ""
echo -e "\e[00;32m#############################################################\e[00m"
echo ""
echo "*** Airmon-NG setup script for the Pwnpad Version $VERSION  ***"
echo "*** Author: @securemaryland ***"
echo "*** Launches airmon-ng and puts Wlan1 in monitoring mode  ***"
echo ""
echo -e "\e[00;32m#############################################################\e[00m"
echo ""
echo ""
echo -e "\e[1;33mPress Enter to continue\e[00m"
echo ""
read ENTERKEY
clear
}
##########################################################################################################################
##########################################################################################################################
# Function to check for wlan1 and set up monitoring
f_wireless(){
adaptor=`ip addr |grep wlan1`
if [ -z "$adaptor" ]; then
echo "This script requires wlan1 to be plugged in."
echo "I cant see it so exiting now. Try again when wlan1 is plugged in."
echo "Please press enter to exit"
read ENTERKEY
exit 1
fi
echo " Found wlan1 now checking if monitor mode is on - don't worry I will turn it on if it isn't running"
echo -e "\e[1;33m------------------------------------------------------------------\e[00m"
iwconfig |grep Monitor>/dev/null
if [ $? = 1 ]
then
	while true; do
		echo ""
	echo "Monitor mode doesn't seem to be running. I will issue an airmon-ng start wlan1 to start it"
	echo ""
	echo "Would you like to monitor a single channel or all?"
	echo "1) Single"
	echo "2) All"
	read monChoice
		case $monChoice in
		1) 	echo "Ok. What channel would you like to monitor? [1-14]:"
				read monChannel
					case $monChannel in
					[1-15]) echo "starting monitoring on channel $monChannel" 
							airmon-ng start wlan1 $monChannel
							break;
							;;
					*) echo "Not a proper channel. Please start over."
					;;
					esac
					;;
		2) 	echo "Ok will monitor all channels"
				airmon-ng start wlan1
				break;
				;;
	*) echo "Invalid Input. Please enter valid number [1-2]" 
	;;
esac
done
else
	echo "Monitor mode appears to be running. Nothing more to do here."
fi
}
##########################################################################################################################
f_intro
f_wireless
