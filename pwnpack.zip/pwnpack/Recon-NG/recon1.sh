cd /opt/pwnpad/recon/
./recon-ng.py
