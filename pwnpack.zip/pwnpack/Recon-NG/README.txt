****Pwnpad Goodness brought to you by @securemaryland****

This script  doesn't install recon-ng it will simply launch it. You will need to download recon-ng on your own and modify recon1.sh to point to the install folder. 

Copy both the recon.sh and the recon1.sh to the /opt/pwnpad/scripts folder install the Recon-NG.apk and enjoy.